import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SuppliersRoutingModule } from './suppliers-routing.module';
import { SuppliersListComponent } from './suppliers-list/suppliers-list.component';
import { SupplierRequestComponent } from './supplier-request/supplier-request.component';

@NgModule({
  imports: [
    CommonModule,
    SuppliersRoutingModule
  ],
  declarations: [SuppliersListComponent, SupplierRequestComponent],
  exports: [SuppliersListComponent, SupplierRequestComponent]
})
export class SuppliersModule { }
