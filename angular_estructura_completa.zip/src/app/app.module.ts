import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { CommonsModule } from './commons/commons.module';
import { FromSuppliersComponent } from './billing/from-suppliers/from-suppliers.component';
import { ToCustomersComponent } from './billing/to-customers/to-customers.component';


@NgModule({
  declarations: [
    AppComponent,
    FromSuppliersComponent,
    ToCustomersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonsModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [FromSuppliersComponent, ToCustomersComponent]
})
export class AppModule { }
